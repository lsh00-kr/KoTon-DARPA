# KoTon Preprocessed Data Handoff (2026-11-23)

## 1. Purpose
Provide preprocessed feature matrices, feature definitions,
normalization details, and ground-truth labels for GNN development.

## 2. Preprocessed CSV Files
- unified/5m_unified_node_features.csv: 34,835 nodes
- unified/6r_unified_node_features.csv: 1,393 nodes
- feature_matrices/: separate process, file, and socket CSVs

Each unified CSV row represents one node.
There are 44 numeric model features:
- 16 process-specific features
- 12 file-specific features
- 8 socket-specific features
- 8 common event-derived features

Non-applicable node-type features are zero-filled.
See unified/UNIFIED_FEATURE_GUIDE.md for column definitions.

## 3. Normalization
Original process, file, and socket features use different
type-specific transformations.

Common event features are defined consistently across node types,
but timestamp and event-count normalization parameters are
calculated separately for the 5m and 6r datasets.

Actor UID is not consistently available for all node types.
No global z-score normalization was applied.

## 4. Ground Truth
The target column is 'label':
- 1: attack UUID matched to REAPr research labels
- 0: date-assumed benign (not individually verified)
- -1: unknown (NOT confirmed benign)

Original 6r unified matrix:
- 33 attack process nodes
- 140 unknown process nodes
- File and socket labels are unknown

Expanded 6r process matrix:
- expanded_attack/6r_expanded_process_189.csv
- 189 process nodes
- 49 attack labels
- 140 unknown labels
- No confirmed benign labels

The expanded process CSV is separate from the original
6r unified CSV. Do not assume the original unified CSV
contains all 49 attack nodes.

## 5. Incomplete Expansion
The additional 16 attack processes have verified
16-dimensional process-specific features.

Their eight common event-derived features are incomplete.
Do not treat the expanded 44-dimensional matrix as complete.

## 6. Graph Validation (Separate Work)
A partial expanded graph was structurally validated:
- 189 process, 1,215 file, and 5 socket nodes
- 11 additional in-window verified clone edges
- PyTorch Geometric forward pass completed successfully

The graph .pt file is NOT included in this CSV handoff ZIP.
A successful forward pass does NOT establish detection accuracy.

## 7. Limitations
- The 5m benign labels rely on a date-based assumption.
- The 6r dataset lacks confirmed benign ground truth.
- Dataset-specific normalization may cause comparability issues.
- Unknown labels must never be converted to benign automatically.
- The unified CSV contains event-derived aggregate features;
  it is not strictly a parsing-only feature matrix.
- Current data is not a fully verified binary benchmark.

## 8. Next Steps
1. Complete event-derived features for the 16 added processes.
2. Obtain reliable benign ground truth.
3. Expand attack scenarios and evaluate label coverage.
4. Establish consistent preprocessing and leakage-safe splits.
5. Train and evaluate the GNN.
