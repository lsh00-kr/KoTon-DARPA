# KoTon Unified Node Feature Guide

## 1. Files

- `5m_unified_node_features.csv`: 34,835 nodes, 50 columns
- `6r_unified_node_features.csv`: 1,393 nodes, 50 columns

Each row represents one node (process, file, or socket).
Rows are aligned to the original full graph node indices.

## 2. Column structure

### Metadata (not model input)
- `dataset`: 5m or 6r
- `node_type`: process, file, socket
- `node_index`: original graph node index
- `node_uuid`: original node UUID

### Type-specific input features (36 columns)
- `process_feature_0` through `process_feature_15`
- `file_feature_0` through `file_feature_11`
- `socket_feature_0` through `socket_feature_7`

Only the columns corresponding to the row's node type contain
its original feature values. Other node-type feature columns are
zero-filled (not observed values).

### Common input features (8 columns)
- `observed`: 1 if the node appears in a source event, otherwise 0
- `first_time_norm`: normalized first observed event timestamp
- `last_time_norm`: normalized last observed event timestamp
- `active_duration_norm`: normalized difference between last and first timestamps
- `event_count_norm`: normalized number of incident event endpoints
- `read_count_norm`: normalized number of incident read event endpoints
- `write_count_norm`: normalized number of incident write event endpoints
- `connect_count_norm`: normalized number of incident connect event endpoints

The count features count both source and destination appearances.
A self-loop would contribute two endpoint appearances.

For nodes with `observed=0`, all seven other common features
are zero-filled and should be treated as unavailable, not as
verified zero activity.

### Target columns (never model input)
- `label`: 1=research-confirmed attack, 0=date-assumed benign,
  -1=unknown
- `label_source`: origin of the label

## 3. Original process features (16)

- 0: UID equals 0 flag (root); unknown UID may be encoded as 1000
- 1: min(log(max(PID,1)+1)/10, 1)
- 2: suspicious process-name substring flag
- 3: executable path contains /tmp or /dev/shm
- 4: hidden executable path/name flag
- 5: min(command-line length/256, 1)
- 6: min(command-line token count/20, 1)
- 7-15: MD5-based executable path/name hash projection /255

## 4. Original file features (12)

- 0: sensitive path substring flag
- 1: /tmp or /dev/shm path flag
- 2: hidden path flag
- 3: executable/script extension flag
- 4: min(path slash count/10, 1)
- 5-11: MD5-based path hash projection /255

## 5. Original socket features (8)

- 0: external IP flag using simple prefix-based local-IP detection
- 1: standard port membership flag
- 2: port > 1024 flag
- 3: suspicious C2/reverse-shell port membership flag
- 4: min(port/65535, 1)
- 5-7: MD5-based IP:port hash projection /255

## 6. Common feature normalization

Time features:
- Normalize event timestamps using (t - dataset_min_time) /
  (dataset_max_time - dataset_min_time).
- Active duration uses the same time span denominator.
- Only source event timestamps are used.
- Node timestamps of 0.0 are not treated as real event times.

Count features:
- Apply log1p(count).
- Divide by the maximum log1p count observed among event-linked
  nodes in the corresponding dataset.
- If the maximum is below 1.0, use denominator 1.0.

IMPORTANT: 5m and 6r have DIFFERENT dataset-specific normalization
denominators. Their normalized values are not automatically
comparable on the same absolute scale.

No global z-score normalization was performed.

## 7. Labels and ground truth

5m:
- 13,915 process nodes labeled 0 using April 9 date assumption
- 1 process node labeled -1
- File/socket labels are -1

6r:
- 33 process nodes labeled 1 based on matching REAPr attack UUIDs
- 140 process nodes labeled -1
- File/socket labels are -1

The 5m benign labels are NOT individually verified ground truth.
The 6r attack labels are research-derived UUID matches.
Unknown (-1) does NOT mean benign.

Do not use `label`, `label_source`, or `dataset` as model inputs.
Using `dataset` as a feature can leak the attack/benign collection
distinction. The same risk exists for dataset-specific feature
normalization and collection-period differences.

## 8. Full versus connected graphs

The unified CSV files contain ALL nodes, including isolated nodes.

The connected graph files are:
- `labeled/5m_connected_graph.pt`
- `labeled/6r_connected_graph.pt`

Use each node type's `original_node_index` in the connected graph
to select corresponding rows from the unified CSV.

The original type-specific graph `.x` tensors have NOT been replaced
with the 44-column unified features.

## 9. Important limitations

- These are node-level features, not an event-level training table.
- Actor UID is not available for all node types.
- Event-based counts are source-event-derived, not necessarily
  identical to augmented graph edge counts.
- Heuristic attack candidate masks are NOT ground truth.
- The current labels do not constitute a fully verified binary
  classification benchmark.
- Random train/test splitting may cause graph-neighborhood leakage.
- Model performance has not yet been validated.
